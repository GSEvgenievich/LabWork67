﻿using DemoWPF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrdersPage.xaml
    /// </summary>
    public partial class OrdersPage : Page
    {

        CollectionViewSource orders;
        User user;

        public OrdersPage(User user)
        {
            InitializeComponent();

            this.user = user;
            orders = (CollectionViewSource)FindResource("orderViewSource");
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new ProductsPage(user, false));
        }

        private void NewOrderButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            orders.Source = Core.Context.Orders.ToList();
            
            if (user.Role != "Администратор")
            {
                NewOrderButton.IsEnabled = false;
            }
        }

        private void orderListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (user.Role == "Администратор")
            {
                
            }
        }
    }
}
