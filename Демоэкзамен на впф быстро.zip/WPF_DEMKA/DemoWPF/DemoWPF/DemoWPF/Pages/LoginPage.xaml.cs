﻿using DemoWPF.Models;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemoWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new ProductsPage(null, true));
        }

        private void AuthorizeButton_Click(object sender, RoutedEventArgs e)
        {
            var user = Core.Context.Users
                .FirstOrDefault(u => u.Login == LoginTextBox.Text && u.Password == PasswordBox.Password);

            if (user != null)
            {
                App.CurrentFrame.Navigate(new ProductsPage(user, false));
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
