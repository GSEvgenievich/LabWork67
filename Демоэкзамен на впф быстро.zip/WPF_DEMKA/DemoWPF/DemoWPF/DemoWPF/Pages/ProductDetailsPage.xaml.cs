﻿using DemoWPF.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace DemoWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductDetailsPage.xaml
    /// </summary>
    public partial class ProductDetailsPage : Page
    {
        CollectionViewSource products;
        User user;

        public ProductDetailsPage(Product product, User user)
        {
            InitializeComponent();
            this.user = user;

            products = (CollectionViewSource)FindResource("productViewSource");

            if (product != null)
            {
                products.Source = Core.Context.Products.Where(x => x.ProductId == product.ProductId).ToList();
            }
            else
            {
                products.Source = new List<Product>() { new Product() { Article = "", Discount = 0, Description = "", CategoryId = 1, ManufacturerId = 1, SupplierId = 1, Photo = null, Name = "", Price = 0, Unit = "", Amount = 0 } };
            }
        }

        private void ImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Images files (*.png;*.jpeg;*.jpg)|*.png;*.jpeg;*.jpg";

            if (openFileDialog.ShowDialog() == true)
            {
                var name = Path.GetFileName(openFileDialog.FileName);
                var newPath = Path.Combine(Environment.CurrentDirectory, "Images", name);

                File.Copy(openFileDialog.FileName, newPath, true);

                (products.View.CurrentItem as Product).Photo = name;
                products.View.Refresh();
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.GoBack();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (user.Role != "Администратор")
            {
                DeleteButton.IsEnabled = false;
            }

            var manufacturer = (CollectionViewSource)FindResource("manufacturerViewSource");
            var supplier = (CollectionViewSource)FindResource("supplierViewSource");
            var category = (CollectionViewSource)FindResource("categoryViewSource");

            category.Source = Core.Context.Categories.ToList();
            supplier.Source = Core.Context.Suppliers.ToList();
            manufacturer.Source = Core.Context.Manufacturers.ToList();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Core.Context.Products.Remove(products.View.CurrentItem as Product);
            Core.Context.SaveChanges();
            App.CurrentFrame.GoBack();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Core.Context.Products.AddOrUpdate(products.View.CurrentItem as Product);
            Core.Context.SaveChanges();
            App.CurrentFrame.GoBack();
        }
    }
}
