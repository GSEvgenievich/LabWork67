﻿using DemoWPF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductsPage.xaml
    /// </summary>
    public partial class ProductsPage : Page
    {
        CollectionViewSource products;
        User user;
        bool isGuest;

        public ProductsPage(User user, bool isGuest)
        {
            InitializeComponent();
            products = (CollectionViewSource)FindResource("productViewSource");

            this.user = user;
            this.isGuest = isGuest;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            products.Source = Core.Context.Products.ToList();

            FilterBox.ItemsSource = Core.Context.Suppliers.Select(x => x.Name).Prepend("Все поставщики").ToList();
            FilterBox.SelectedIndex = 0;
            SortBox.SelectedIndex = 0;

            if (isGuest || user.Role == "Авторизированный клиент")
            {
                FilterPanel.Visibility = Visibility.Collapsed;
                NewProductButton.Visibility = Visibility.Collapsed;
                OrdersButton.Visibility = Visibility.Collapsed;
            }

            if (isGuest)
            {
                UserNameLabel.Content = "Гость";
            }
            else
            {
                UserNameLabel.Content = user.FullName;
            }
        }

        private bool Search(object o)
        {
            Product product = o as Product;
            return product.Name.ToLower().Contains(SearchBox.Text.ToLower())
                || product.Description.Contains(SearchBox.Text.ToLower())
                || product.Article.Contains(SearchBox.Text.ToLower())
                || product.Category.Name.Contains(SearchBox.Text.ToLower())
                || product.Manufacturer.Name.Contains(SearchBox.Text.ToLower())
                || product.Supplier.Name.Contains(SearchBox.Text.ToLower());
        }

        private bool Filter(object o)
        {
            Product product = (Product)o;

            if (FilterBox.SelectedIndex == 0)
                return true;

            return product.Supplier.Name == FilterBox.SelectedValue.ToString();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show("Вы точно хотите выйти?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirm == MessageBoxResult.Yes)
            {
                App.CurrentFrame.Navigate(new LoginPage());
            }
        }

        private void FiltersChanged(object sender, EventArgs e)
        {
            products.View.Filter = x => Search(x) && Filter(x);
            products.View.SortDescriptions.Clear();

            switch (SortBox.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    products.View.SortDescriptions.Add(new SortDescription("Amount", ListSortDirection.Ascending));
                    break;
                case 2:
                    products.View.SortDescriptions.Add(new SortDescription("Amount", ListSortDirection.Descending));
                    break;
                default:
                    break;
            }
        }

        private void productListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!isGuest)
                App.CurrentFrame.Navigate(new ProductDetailsPage(productListView.SelectedItem as Product, user));
        }

        private void OrdersButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new OrdersPage(user));
        }

        private void NewProductButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new ProductDetailsPage(null, user));
        }
    }
}
