﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWPF.Models
{
    public static class Core
    {
        private static DemoWFP_Entities context;
        public static DemoWFP_Entities Context => context ?? (context = new DemoWFP_Entities());
    }
}
