﻿using System;
using System.IO;

namespace DemoWPF.Models
{
    partial class Product
    {
        public string PhotoPath => Path.Combine(Environment.CurrentDirectory, "Images",
                string.IsNullOrWhiteSpace(Photo) ? "picture.png" : Photo);

        public bool HasDiscount => Discount > 0;
        public bool IsBigDiscount => Discount > 15;
        public decimal DiscountedPrice => Price * (decimal)(1 - Discount / 100);
    }
}
