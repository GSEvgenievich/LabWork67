﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NS_DEMO_WINFORM
{
    public partial class ProductForm : Form
    {
        private NS_DemDataSet.UsersRow User { get; set; }
        private bool IsGuest { get; set; } = false;

        private AuthorizeForm AuthorizeForm {  get; set; }

        public ProductForm(AuthorizeForm authorizeForm, NS_DemDataSet.UsersRow user, bool isGuest)
        {
            InitializeComponent();

            AuthorizeForm = authorizeForm;
            User = user;
            IsGuest = isGuest;
        }

        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.nS_DemDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!IsGuest && User == null)
            {
                Close();
            }
            else if (IsGuest)
            {
                UserLabel.Text = "Гость";
                SortComboBox.Hide();
                SortLabel.Hide();
                FilterComboBox.Hide();
                Filterlabel.Hide();
                SearchTextBox.Hide();
                SearchLabel.Hide();
            }
            else
            { 
                UserLabel.Text = User.FullName;

                if (User.Role == "Авторизированный клиент")
                {
                    SortComboBox.Hide();
                    SortLabel.Hide();
                    FilterComboBox.Hide();
                    Filterlabel.Hide();
                    SearchTextBox.Hide();
                    SearchLabel.Hide();
                }
            }

            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Categories". При необходимости она может быть перемещена или удалена.
            this.categoriesTableAdapter.Fill(this.nS_DemDataSet.Categories);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Manufacturers". При необходимости она может быть перемещена или удалена.
            this.manufacturersTableAdapter.Fill(this.nS_DemDataSet.Manufacturers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Suppliers". При необходимости она может быть перемещена или удалена.
            this.suppliersTableAdapter.Fill(this.nS_DemDataSet.Suppliers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.nS_DemDataSet.Products);

            SortComboBox.SelectedIndex = 0;
            FilterComboBox.Items.Add("Все поставщики");
            FilterComboBox.Items.AddRange(nS_DemDataSet.Suppliers.ToArray());
            FilterComboBox.DisplayMember = "Name";
            FilterComboBox.SelectedIndex = 0;
        }

        private void productsDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (productsDataGridView.Columns[e.ColumnIndex].Name.Equals(nameof(PhotoColumn)))
            {
                if (!string.IsNullOrWhiteSpace(e.Value as string))
                {
                    e.Value = Image.FromFile($"Images\\{e.Value}");
                }
                else
                {
                    e.Value = Image.FromFile($"Images\\picture.png");
                }
            }
            else if (productsDataGridView.Columns[e.ColumnIndex].Name.Equals(nameof(DiscountColumn)))
            {
                double discount = (double)e.Value;
                if (discount > 15)
                {
                    productsDataGridView.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.FromArgb(0x2e, 0x8b, 0x57);
                }
            }
            else if (productsDataGridView.Columns[e.ColumnIndex].Name.Equals(nameof(AmountColumn)))
            {
                int amount = (int)e.Value;
                if (amount == 0)
                {
                    productsDataGridView.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightCoral;
                }
            }
        }

        private void productsDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            AuthorizeForm.Show();
            this.Close();
        }

        private string search;
        private string filter;
        private string sort;

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            var text = SearchTextBox.Text;

            search = $"(Article LIKE '%{text}%'" +
                $"OR Name LIKE '%{text}%'" +
                $"OR Description LIKE '%{text}%')";

            SetFilter();
        }

        private void SortComboBox_SelectedValueChanged(object sender, EventArgs e)
        {
            if (SortComboBox.SelectedIndex == 0)
            {
                sort = "";
            }
            else if (SortComboBox.SelectedIndex == 1)
            {
                sort = "Amount DESC";
            }
            else
            {
                sort = "Amount ASC";
            }

            SetFilter();
        }

        private void FilterComboBox_SelectedValueChanged(object sender, EventArgs e)
        {
            if (FilterComboBox.SelectedIndex == 0)
            {
                filter = "";
            }
            else
            {
                filter = $"(SupplierId = '{(FilterComboBox.SelectedItem as NS_DemDataSet.SuppliersRow).SupplierId}')";
            }

            SetFilter();
        }

        private void SetFilter()
        {
            string and = "";

            if (!String.IsNullOrWhiteSpace(filter) && !String.IsNullOrWhiteSpace(search))
            {
                and = " AND ";
            }

            this.productsBindingSource.Filter = search + and + filter;
            this.productsBindingSource.Sort = sort;
        }

        private void productsDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int id = (int)productsDataGridView.Rows[e.RowIndex].Cells[nameof(ProductIdColumn)].Value;
                ProductDetailsForm productDetailsForm = new ProductDetailsForm(id);
                Hide();
                productDetailsForm.ShowDialog();
                Show();
            }
            catch(ArgumentOutOfRangeException) 
            {
                
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            ProductDetailsForm productDetailsForm = new ProductDetailsForm(null);
            Hide();
            productDetailsForm.ShowDialog();
            Show();
        }

        private void OrdersButton_Click(object sender, EventArgs e)
        {
            OrderForm orderForm = new OrderForm();
            Hide();
            orderForm.ShowDialog();
            Show();
        }
    }
}
