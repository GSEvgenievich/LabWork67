﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NS_DEMO_WINFORM
{
    public partial class OrderForm : Form
    {
        public OrderForm()
        {
            InitializeComponent();
        }

        private void ordersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.ordersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.nS_DemDataSet);

        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter.Fill(this.nS_DemDataSet.Users);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.PickupPoints". При необходимости она может быть перемещена или удалена.
            this.pickupPointsTableAdapter.Fill(this.nS_DemDataSet.PickupPoints);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter.Fill(this.nS_DemDataSet.Users);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.PickupPoints". При необходимости она может быть перемещена или удалена.
            this.pickupPointsTableAdapter.Fill(this.nS_DemDataSet.PickupPoints);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Orders". При необходимости она может быть перемещена или удалена.
            this.ordersTableAdapter.Fill(this.nS_DemDataSet.Orders);

        }

        private void ordersDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (ordersDataGridView.Columns[e.ColumnIndex].Name.Equals(nameof(OrderProductsColumn)))
            {
                
            }
        }
    }
}
