﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace NS_DEMO_WINFORM
{
    public partial class AuthorizeForm : Form
    {
        public AuthorizeForm()
        {
            InitializeComponent();
        }

        private void GuestButton_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm(this, null, true);
            productForm.ShowDialog();
            Hide();
        }

        private void AuthorizeButton_Click(object sender, EventArgs e)
        {
            var user = nS_DemDataSet.Users
                .FirstOrDefault(x => x.Login == LoginTextBox.Text
                && x.Password == PasswordTextBox.Text);

            if (user != null)
            {
                Hide();

                ProductForm productForm = new ProductForm(this, user, false);
                productForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Введены некорректные учётные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AuthorizeForm_Load(object sender, EventArgs e)
        {
            this.usersTableAdapter1.Fill(nS_DemDataSet.Users);
        }
    }
}
