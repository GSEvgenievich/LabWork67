﻿using System;
using System.Data;
using System.Windows.Forms;

namespace NS_DEMO_WINFORM
{
    public partial class ProductDetailsForm : Form
    {
        private int? Id { get; set; }

        public ProductDetailsForm(int? id)
        {
            InitializeComponent();
            Id = id;
        }

        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Завершаем редактирование в полях формы
                articleTextBox.DataBindings["Text"].WriteValue();
                nameTextBox.DataBindings["Text"].WriteValue();
                unitTextBox.DataBindings["Text"].WriteValue();
                priceTextBox.DataBindings["Text"].WriteValue();
                discountTextBox.DataBindings["Text"].WriteValue();
                amountTextBox.DataBindings["Text"].WriteValue();
                descriptionTextBox.DataBindings["Text"].WriteValue();

                // Валидация обязательных полей
                if (string.IsNullOrWhiteSpace(articleTextBox.Text))
                {
                    MessageBox.Show("Артикул не может быть пустым!");
                    return;
                }

                if (string.IsNullOrWhiteSpace(nameTextBox.Text))
                {
                    MessageBox.Show("Название не может быть пустым!");
                    return;
                }

                // Конвертируем значения
                decimal price;
                if (!decimal.TryParse(priceTextBox.Text, out price))
                {
                    MessageBox.Show("Некорректная цена!");
                    return;
                }

                decimal discount;
                if (!decimal.TryParse(discountTextBox.Text, out discount))
                {
                    MessageBox.Show("Некорректная скидка!");
                    return;
                }

                int amount;
                if (!int.TryParse(amountTextBox.Text, out amount))
                {
                    MessageBox.Show("Некорректное количество!");
                    return;
                }

                // Проверяем, что выбраны справочники
                if (supplierIdComboBox.SelectedValue == null)
                {
                    MessageBox.Show("Выберите поставщика!");
                    return;
                }

                if (manufacturerIdComboBox.SelectedValue == null)
                {
                    MessageBox.Show("Выберите производителя!");
                    return;
                }

                if (categoryIdComboBox.SelectedValue == null)
                {
                    MessageBox.Show("Выберите категорию!");
                    return;
                }

                // Сохраняем изменения в текущей строке
                var currentRow = productsBindingSource.Current as DataRowView;
                if (currentRow != null)
                {
                    // Обновляем значения
                    currentRow["Article"] = articleTextBox.Text;
                    currentRow["Name"] = nameTextBox.Text;
                    currentRow["Unit"] = unitTextBox.Text;
                    currentRow["Price"] = price;
                    currentRow["Discount"] = discount;
                    currentRow["Amount"] = amount;
                    currentRow["Description"] = descriptionTextBox.Text;
                    currentRow["SupplierId"] = supplierIdComboBox.SelectedValue;
                    currentRow["ManufacturerId"] = manufacturerIdComboBox.SelectedValue;
                    currentRow["CategoryId"] = categoryIdComboBox.SelectedValue;

                    // Обработка изображения
                    // (если нужно загружать новое изображение, добавьте эту логику здесь)
                }

                // Сохраняем в базу данных
                this.Validate();
                this.productsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.nS_DemDataSet);

                MessageBox.Show("Данные успешно сохранены!");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void ProductDetailsForm_Load(object sender, EventArgs e)
        {

            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Categories". При необходимости она может быть перемещена или удалена.
            this.categoriesTableAdapter.Fill(this.nS_DemDataSet.Categories);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Manufacturers". При необходимости она может быть перемещена или удалена.
            this.manufacturersTableAdapter.Fill(this.nS_DemDataSet.Manufacturers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Suppliers". При необходимости она может быть перемещена или удалена.
            this.suppliersTableAdapter.Fill(this.nS_DemDataSet.Suppliers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nS_DemDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.nS_DemDataSet.Products);

            if (Id != null)
            {
                productsBindingSource.Filter = $"ProductId = {Id}";

                if (!string.IsNullOrWhiteSpace(photoPictureBox.ImageLocation))
                {
                    photoPictureBox.ImageLocation = $"Images\\{photoPictureBox.ImageLocation}";
                }
                else
                {
                    photoPictureBox.ImageLocation = $"Images\\picture.png";
                }
            }
            else
            {
                productsBindingSource.AddNew();

                var newRow = productsBindingSource.Current as DataRowView;
                if (newRow != null)
                {
                    newRow["Discount"] = 0;
                    newRow["Amount"] = 0;
                    newRow["Price"] = 0;
                }

                photoPictureBox.ImageLocation = $"Images\\picture.png";
            }
        }
    }
}
