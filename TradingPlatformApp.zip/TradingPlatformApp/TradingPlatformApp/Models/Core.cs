﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingPlatformApp.Models
{
    public static class Core
    {
        private static ArtsDbEntities context;
        public static ArtsDbEntities Context => context ?? (context = new ArtsDbEntities());
    }
}
