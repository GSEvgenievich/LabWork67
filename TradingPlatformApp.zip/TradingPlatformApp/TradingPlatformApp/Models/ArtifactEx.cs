﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingPlatformApp.Models
{
    partial class Artifact
    {
        public string PhotoPath => Path.Combine(Environment.CurrentDirectory, "Images", ArtifactId.ToString() + ".png");
        public int LotsCount => Lots.Count;

        public decimal MinPrice => LotsCount > 0 ? Lots.Min(l => l.Price) : 0;

        public int RarityInt =>
            Rarity == "Обычный" ? 1 :
            Rarity == "Редкий" ? 2 :
            Rarity == "Уникальный" ? 3 :
            Rarity == "Легендарный" ? 4 : 0;
    }
}
