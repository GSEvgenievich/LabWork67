﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using TradingPlatformApp.Models;

namespace TradingPlatformApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для MyLotDetailsPage.xaml
    /// </summary>
    public partial class MyLotDetailsPage : Page
    {
        CollectionViewSource lots;
        CollectionViewSource artifacts;
        Lot lot;
        User user;
        Artifact artifact;

        public MyLotDetailsPage(Lot lot, Artifact artifact, User user)
        {
            InitializeComponent();

            artifacts = (CollectionViewSource)FindResource("artifactsViewSource");
            lots = (CollectionViewSource)FindResource("lotsViewSource");

            this.lot = lot;
            this.user = user;
            this.artifact = artifact;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Core.Context.Lots.AddOrUpdate(lots.View.CurrentItem as Lot);
            Core.Context.SaveChanges();
            App.CurrentFrame.GoBack();
        }

        private void MyLotsButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new MyLotsPage(user));
        }

        private void ToProductButtons_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show("Вы точно хотите выйти?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirm == MessageBoxResult.Yes)
            {
                App.CurrentFrame.Navigate(new LoginPage());
            }
        }

        private void artifactsListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            artifactIdTextBox.Text = (artifactsListView.SelectedItem as Artifact).ArtifactId.ToString();
            (lots.View.CurrentItem as Lot).ArtifactId = Convert.ToInt32(artifactIdTextBox.Text);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            UserNameLabel.Content = user.Login;
            artifacts.Source = Core.Context.Artifacts.ToList();

            if (lot != null)
            {
                lots.Source = new List<Lot>() { lot };
            }
            else
            {
                lots.Source = new List<Lot>() { new Lot() { ArtifactId = artifact == null ? 1 : artifact.ArtifactId, UserId = user.UserId, Date = DateTime.Now, Quantity = 0, Price = 0 } };
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Core.Context.Lots.Remove(lots.View.CurrentItem as Lot);
            Core.Context.SaveChanges();
            App.CurrentFrame.Navigate(new MyLotsPage(user));
        }
    }
}
