﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TradingPlatformApp.Models;

namespace TradingPlatformApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для ArtifactsPage.xaml
    /// </summary>
    public partial class ArtifactsPage : Page
    {
        CollectionViewSource artifacts;
        User user;

        public ArtifactsPage(User user)
        {
            InitializeComponent();

            artifacts = (CollectionViewSource)FindResource("artifactsViewSource");

            this.user = user;
        }

        private void NewArtifactButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show("Вы точно хотите выйти?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirm == MessageBoxResult.Yes)
            {
                App.CurrentFrame.Navigate(new LoginPage());
            }
        }

        private void MyLotsButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new MyLotsPage(user));
        }

        private void FiltersChanged(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = sender as TextBox;

                if (System.Text.RegularExpressions.Regex.IsMatch(textBox.Text, "[^0-9]"))
                {
                    textBox.Text = System.Text.RegularExpressions.Regex.Replace(textBox.Text, "[^0-9]", "");

                    textBox.SelectionStart = textBox.Text.Length;

                    return;
                }
            }

            artifacts.View.Filter = x => CheckMinPrice(x) && FilterRarity(x);
            artifacts.View.SortDescriptions.Clear();

            switch (SortBox.SelectedIndex)
            {
                case 0:
                    artifacts.View.SortDescriptions.Add(new SortDescription("ArtifactId", ListSortDirection.Ascending));
                    break;
                case 1:
                    artifacts.View.SortDescriptions.Add(new SortDescription("RarityInt", ListSortDirection.Ascending));
                    break;
                case 2:
                    artifacts.View.SortDescriptions.Add(new SortDescription("RarityInt", ListSortDirection.Descending));
                    break;
                case 3:
                    artifacts.View.SortDescriptions.Add(new SortDescription("MinPrice", ListSortDirection.Ascending));
                    break;
                case 4:
                    artifacts.View.SortDescriptions.Add(new SortDescription("MinPrice", ListSortDirection.Descending));
                    break;
                default:
                    break;
            }
        }

        private bool FilterRarity(object x)
        {
            Artifact artifact = (Artifact)x;

            if (FilterBox.SelectedIndex == 0)
                return true;

            return (FilterBox.SelectedValue.ToString()).Contains(artifact.Rarity);
        }

        private bool CheckMinPrice(object x)
        {
            Artifact artifact = (Artifact)x;

            if (string.IsNullOrWhiteSpace(MinPriceTextBox.Text))
                return true;

            return artifact.MinPrice > Convert.ToDecimal(MinPriceTextBox.Text);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            UserNameLabel.Content = user.Login;
            artifacts.Source = Core.Context.Artifacts.ToList();
            FilterBox.SelectedIndex = 0;
            SortBox.SelectedIndex = 0;
        }

        private void artifactsListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            App.CurrentFrame.Navigate(new ArtifactLotsPage(artifactsListView.SelectedItem as Artifact, user));
        }
    }
}
