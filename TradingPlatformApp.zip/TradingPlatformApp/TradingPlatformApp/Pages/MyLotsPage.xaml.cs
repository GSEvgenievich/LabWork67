﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using TradingPlatformApp.Models;

namespace TradingPlatformApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для MyLotsPage.xaml
    /// </summary>
    public partial class MyLotsPage : Page
    {
        CollectionViewSource lots;
        User user;

        public MyLotsPage(User user)
        {
            InitializeComponent();
            lots = (CollectionViewSource)FindResource("lotsViewSource");

            this.user = user;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            lots.Source = Core.Context.Lots.Where(l => l.UserId == user.UserId).ToList();

            UserNameLabel.Content = user.Login;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show("Вы точно хотите выйти?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirm == MessageBoxResult.Yes)
            {
                App.CurrentFrame.Navigate(new LoginPage());
            }
        }

        private void FiltersChanged(object sender, EventArgs e)
        {

        }

        private void ToProductButtons_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new ArtifactsPage(user));
        }

        private void NewLotButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new MyLotDetailsPage(null, null, user));
        }

        private void lotsListView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            App.CurrentFrame.Navigate(new MyLotDetailsPage(lotsListView.SelectedItem as Lot, null, user));  
        }
    }
}
