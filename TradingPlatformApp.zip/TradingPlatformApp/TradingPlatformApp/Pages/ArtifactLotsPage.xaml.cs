﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using TradingPlatformApp.Models;

namespace TradingPlatformApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для ArtifactLotsPage.xaml
    /// </summary>
    public partial class ArtifactLotsPage : Page
    {
        CollectionViewSource lots;
        CollectionViewSource artifacts;
        Artifact artifact;
        User user;

        public ArtifactLotsPage(Artifact artifact, User user)
        {
            InitializeComponent();
            lots = (CollectionViewSource)FindResource("lotsViewSource");
            artifacts = (CollectionViewSource)FindResource("artifactViewSource");

            this.artifact = artifact;
            this.user = user;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            artifacts.Source = new ObservableCollection<Artifact>() { artifact };
            lots.Source = new ObservableCollection<Lot>(artifact.Lots);

            UserNameLabel.Content = user.Login;
        }

        private void MyLotsButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new MyLotsPage(user));
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show("Вы точно хотите выйти?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirm == MessageBoxResult.Yes)
            {
                App.CurrentFrame.Navigate(new LoginPage());
            }
        }

        private void ToProductButtons_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new ArtifactsPage(user));
        }

        private void CreateLotButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.Navigate(new MyLotDetailsPage(null, artifact, user));
        }
    }
}
